package com.dh.integrador.login;

public enum AppUsuarioRoles {
    USER,ADMIN

}
