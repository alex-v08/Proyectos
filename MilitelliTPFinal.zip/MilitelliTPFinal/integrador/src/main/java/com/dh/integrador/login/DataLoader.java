package com.dh.integrador.login;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;


@Component
public class DataLoader implements ApplicationRunner {
    private UserRepository userRepository;

@Autowired
    public DataLoader(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

@Override
    public void run(ApplicationArguments args) throws Exception {
        PasswordEncoder passwordEncoder = new PasswordEncoder();
        String password = passwordEncoder.encode("password");
        String password2 = passwordEncoder.encode("password2");
        userRepository.save(new AppUserService("user", password, "USER"));
        userRepository.save(new AppUserService("admin", password2, "ADMIN"));

    userRepository.save(new AppUser("Ricardo", "ricardo", "ricardo@digitalhouse.com", password, AppUsuarioRoles.ADMIN ));
    userRepository.save(new AppUser("Ricardito", "ricardito", "ricardito@digitalhouse.com", password, AppUsuarioRoles.USER ));

}
}
