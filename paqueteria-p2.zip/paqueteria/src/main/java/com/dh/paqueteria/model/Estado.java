package com.dh.paqueteria.model;

public enum Estado {

    POR_RECOGER,EN_CAMINO,ENTREGADO;
}
